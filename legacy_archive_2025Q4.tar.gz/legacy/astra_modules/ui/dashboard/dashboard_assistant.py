"""
Astra Intelligence — Sidebar AI Assistant (v1)
-----------------------------------------------
Local LLaMA-powered assistant integrated with Guardian.
Understands Astra Intelligence context, system health, and trading state.
"""

import json
import subprocess
from datetime import datetime
from pathlib import Path

import streamlit as st

# Optional Hugging Face fallback
try:
    from transformers import pipeline
except ImportError:
    pipeline = None


class AstraAssistant:
    def __init__(self, guardian=None):
        self.guardian = guardian
        self.log_path = (
            Path(__file__).resolve().parents[2] / "guardian" / "guardian_v6.log"
        )
        self.history_file = (
            Path(__file__).resolve().parents[3] / "astra_chat_history.json"
        )
        self.load_history()
        self.model_mode = "ollama" if self._detect_ollama() else "transformers"

        if self.model_mode == "transformers" and pipeline:
            self.model = pipeline(
                "text-generation", model="meta-llama/Llama-3-8b", device_map="auto"
            )
        else:
            self.model = None

    def _detect_ollama(self):
        """Detect if Ollama is installed."""
        try:
            subprocess.run(["ollama", "list"], capture_output=True, text=True)
            return True
        except Exception:
            return False

    def load_history(self):
        """Load previous chat messages."""
        if self.history_file.exists():
            with open(self.history_file, "r") as f:
                self.history = json.load(f)
        else:
            self.history = []

    def save_history(self):
        """Save chat messages persistently."""
        with open(self.history_file, "w") as f:
            json.dump(self.history, f, indent=2)

    def query_llama(self, prompt: str):
        """Send prompt to local LLaMA via Ollama or Transformers."""
        if self.model_mode == "ollama":
            result = subprocess.run(
                ["ollama", "run", "llama3", prompt], capture_output=True, text=True
            )
            return result.stdout.strip()
        elif self.model_mode == "transformers" and self.model:
            result = self.model(prompt, max_length=400, temperature=0.7)
            return result[0]["generated_text"]
        else:
            return (
                "⚠️ No AI model available. Please install Ollama or Hugging Face LLaMA."
            )

    def get_context(self):
        """Fetch system context from Guardian and Astra modules."""
        context = ""
        if self.log_path.exists():
            try:
                with open(self.log_path, "r") as f:
                    recent_logs = f.readlines()[-10:]
                    context += "\n".join(recent_logs)
            except Exception:
                context += "[No Guardian log data available.]"
        return f"""
        SYSTEM CONTEXT:
        - Guardian Status: Active
        - Last logs: {context}
        - Core Modules: guardian_log, Dashboard, Data, Chart, Learning
        """

    def ask(self, question: str):
        """Ask Astra a question and get a contextually aware answer."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        context = self.get_context()
        prompt = f"""
        You are Astra Intelligence — a self-healing, AI-driven trading and diagnostics system.
        Using the context below, answer clearly and technically.

        {context}

        User: {question}
        Astra:
        """

        response = self.query_llama(prompt)
        self.history.append({"time": timestamp, "user": question, "astra": response})
        self.save_history()
        return response

    def render_chat_ui(self):
        """Render chat interface inside Streamlit sidebar."""
        st.markdown("### 🤖 Astra Assistant")
        st.caption(
            "Ask questions about Guardian, market data, or Astra Intelligence internals."
        )

        for chat in reversed(self.history[-5:]):
            st.markdown(f"🧑‍💻 **You ({chat['time']}):** {chat['user']}")
            st.markdown(f"💡 **Astra:** {chat['astra']}")

        question = st.text_input("Ask Astra something:")
        if st.button("Send"):
            if question.strip():
                answer = self.ask(question)
                st.markdown(f"💡 **Astra:** {answer}")
            else:
                st.warning("Please enter a question.")
